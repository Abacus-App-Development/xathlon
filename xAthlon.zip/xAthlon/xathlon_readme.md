--- General ---
We have made an Android app to help people do home workout in order to maintain a good physical condition.

--- Application Description --- 
This application was developed by a group of students and aims to support 
people in their daily exercise at home. Through proposed exercises of targeted difficulty, nutrition advice and additional
tools, such as the pedometer, the user has the ability to maintain a healthy lifestyle. 


--- Instructions --- 
You can directly install the app on your Android phone by installing the file xAthlon_Final.apk.
If you want to see the code with which the app was developed open Android Studio and import the
project in it.


--- About... ---
The app was made by a group of students of the ECE department of Democritus University of Thrace 
as a project to the course "Human – Computer Interaction".
